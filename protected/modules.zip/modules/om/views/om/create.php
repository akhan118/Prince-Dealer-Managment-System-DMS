<?php
/* @var $this OmController */
/* @var $model OrderManagment */

$this->breadcrumbs=array(
	'Order Managments'=>array('index'),
	'Create',
);

$this->menu=array(
	array('label'=>'List OrderManagment', 'url'=>array('index')),
	array('label'=>'Manage OrderManagment', 'url'=>array('admin')),
);
?>

<h1>Create OrderManagment</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>