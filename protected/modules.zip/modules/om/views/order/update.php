<?php
/* @var $this OrderController */
/* @var $model OrderManagment */

$this->breadcrumbs=array(
	'Order Managments'=>array('index'),
	$model->id=>array('view','id'=>$model->id),
	'Update',
);

$this->menu=array(
	array('label'=>'List OrderManagment', 'url'=>array('index')),
	array('label'=>'Create OrderManagment', 'url'=>array('create')),
	array('label'=>'View OrderManagment', 'url'=>array('view', 'id'=>$model->id)),
	array('label'=>'Manage OrderManagment', 'url'=>array('admin')),
);
?>

<h1>Update OrderManagment <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>