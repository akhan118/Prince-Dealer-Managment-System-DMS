<?php
/* @var $this OmController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Order Managments',
);

$this->menu=array(
	array('label'=>'Create OrderManagment', 'url'=>array('vehicles')),
	array('label'=>'Manage OrderManagment', 'url'=>array('admin')),
);
?>

<h1>Order Managments</h1>

<?php $this->widget('zii.widgets.CListView', array(
	'dataProvider'=>$dataProvider,
	'itemView'=>'_view',
)); ?>
