<?php
/* @var $this VehicleController */
/* @var $data Vehicle */
?>

<div class="view">

	<b><?php echo CHtml::encode($data->getAttributeLabel('id')); ?>:</b>
	<?php echo CHtml::link(CHtml::encode($data->id), array('view', 'id'=>$data->id)); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('vin')); ?>:</b>
	<?php echo CHtml::encode($data->vin); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('purchase_date')); ?>:</b>
	<?php echo CHtml::encode($data->purchase_date); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('stock_num')); ?>:</b>
	<?php echo CHtml::encode($data->stock_num); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('year')); ?>:</b>
	<?php echo CHtml::encode($data->year); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('make')); ?>:</b>
	<?php echo CHtml::encode($data->make); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('model')); ?>:</b>
	<?php echo CHtml::encode($data->model); ?>
	<br />

	<?php /*
	<b><?php echo CHtml::encode($data->getAttributeLabel('body_style')); ?>:</b>
	<?php echo CHtml::encode($data->body_style); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('color')); ?>:</b>
	<?php echo CHtml::encode($data->color); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('miles')); ?>:</b>
	<?php echo CHtml::encode($data->miles); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('miles_type')); ?>:</b>
	<?php echo CHtml::encode($data->miles_type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('cost')); ?>:</b>
	<?php echo CHtml::encode($data->cost); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('asking_price')); ?>:</b>
	<?php echo CHtml::encode($data->asking_price); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('title_num')); ?>:</b>
	<?php echo CHtml::encode($data->title_num); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('title_type')); ?>:</b>
	<?php echo CHtml::encode($data->title_type); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('title_origin')); ?>:</b>
	<?php echo CHtml::encode($data->title_origin); ?>
	<br />

	<b><?php echo CHtml::encode($data->getAttributeLabel('cat_fee')); ?>:</b>
	<?php echo CHtml::encode($data->cat_fee); ?>
	<br />

	*/ ?>

</div>